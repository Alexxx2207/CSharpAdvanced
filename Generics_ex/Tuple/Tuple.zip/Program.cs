﻿using System;

namespace Tuple
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] firstPair = Console.ReadLine().Split();
            Tuple1<string, string> pair1 = new Tuple1<string,string>($"{firstPair[0]} {firstPair[1]}", firstPair[2]);
            Console.WriteLine(pair1.Item1 + " -> " + pair1.Item2);
            
            string[] secondtPair = Console.ReadLine().Split();
            Tuple1<string, int> pair2 = new Tuple1<string,int>($"{secondtPair[0]}", int.Parse(secondtPair[1]));
            Console.WriteLine(pair2.Item1 + " -> " + pair2.Item2);
            
            string[] thirdtPair = Console.ReadLine().Split();
            Tuple1<int, double> pair3 = new Tuple1<int, double>(int.Parse(thirdtPair[0]), double.Parse(thirdtPair[1]));
            Console.WriteLine(pair3.Item1 + " -> " + pair3.Item2);
        }
    }
}
